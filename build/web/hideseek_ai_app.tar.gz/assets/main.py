import pygame
import random
import asyncio
import math

# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                        STYLE CONFIGURATION                                  ║
# ║  Edit anything in this block to change the look of the game.                ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

# ── Screen ────────────────────────────────────────────────────────────────────
SCREEN_W, SCREEN_H = 1250, 800

# ── Colours  (R, G, B) ────────────────────────────────────────────────────────
C_BG            = (250, 245, 235)   # page / background
C_BG_DARK       = (240, 232, 218)   # slightly deeper background accent

C_PANEL_BG      = (255, 255, 255)   # white panels
C_PANEL_BORDER  = (255, 182, 193)   # panel border / pink accent

C_PRIMARY       = (248, 140, 160)   # primary button / progress bar
C_PRIMARY_DARK  = (220, 100, 130)   # primary button shadow / dark accent
C_PRIMARY_LIGHT = (255, 182, 193)   # primary button hover / soft pink

C_SECONDARY     = (110, 180, 145)   # secondary (Phase 2 / mint) buttons & accents
C_SECONDARY_LT  = (160, 220, 190)   # secondary light

C_ACCENT_LILAC  = (195, 190, 220)   # intermezzo panel border
C_ACCENT_LILAC2 = (220, 215, 240)   # intermezzo divider / lighter lilac

C_AMBER         = (255, 190,  60)   # stars / trophy
C_AMBER_DARK    = (200, 140,  20)   # amber text

C_GOOD          = (110, 180, 145)   # match flash / "good" badge — same as secondary
C_BAD           = (230, 110, 110)   # mismatch flash / "bad" badge

C_TEXT          = ( 90,  70,  80)   # main body text
C_TEXT_MED      = (150, 130, 145)   # muted / label text
C_WHITE         = (255, 255, 255)
C_SHADOW        = (200, 185, 175)   # drop-shadow tint

# ── Floating background blobs ─────────────────────────────────────────────────
# Each entry: (x_speed, y_speed, x_amplitude, y_amplitude,
#              base_x, base_y, radius, (R,G,B,alpha))
BG_BLOBS = [
    (0.5, 0.3, 18, 12,  100,  120, 28, (*C_PRIMARY_LIGHT, 30)),
    (1.2, 0.7, 14, 20,  350,  680, 22, (160, 210, 240,    35)),
    (0.8, 1.1, 22, 10,  900,  150, 18, (*C_SECONDARY_LT,  40)),
    (1.5, 0.4, 10, 18, 1100,  600, 26, (*C_AMBER,         28)),
    (0.3, 1.3, 20, 14,  600,  700, 20, (*C_ACCENT_LILAC,  38)),
    (1.0, 0.9, 16, 22,  200,  400, 16, (255, 210, 170,    45)),
    (0.6, 0.5, 12, 16,  800,  500, 24, (*C_PRIMARY,       25)),
    (1.8, 1.0, 24,  8,  500,  200, 14, (*C_SECONDARY_LT,  32)),
    (0.4, 1.6,  8, 20, 1050,  350, 20, (160, 210, 240,    30)),
    (1.3, 0.2, 18, 14,  150,  650, 18, (*C_AMBER,         34)),
]

# ── Sparkles ──────────────────────────────────────────────────────────────────
SPARKLE_POSITIONS = [(180,90),(980,130),(60,500),(1140,400),(700,60),(400,750),(1050,700)]
SPARKLE_COLOR     = C_AMBER     # base colour (alpha animated automatically)
SPARKLE_MIN_SIZE  = 4
SPARKLE_MAX_SIZE  = 9

# ── Card layout ───────────────────────────────────────────────────────────────
CARD_SIZE   = 80          # cards are square: CARD_SIZE × CARD_SIZE px
CARD_MARGIN = 10          # gap between cards
CARD_RADIUS = 12          # rounded corner radius on cards
CARD_COLS   = 14          # number of columns in the grid
CARD_HOVER_SCALE = 1.10   # how much cards grow when hovered (1.0 = no grow)
CARD_SHADOW_ALPHA = 40    # card drop-shadow opacity (0=none, 255=solid)

# ── Card colours used when image files are missing (fallback art) ─────────────
FALLBACK_GERM_COLOURS = [
    (160, 210, 240),   # pathogen 0 — sky blue
    (220, 120, 120),   # pathogen 1 — coral
    (160, 200, 130),   # pathogen 2 — sage
    (255, 190,  60),   # pathogen 3 — amber
    (195, 190, 220),   # pathogen 4 — lilac
]
FALLBACK_GERM_SHAPES = ["spiky", "blob", "round", "fuzzy", "cloud"]

# ── HUD bar ───────────────────────────────────────────────────────────────────
HUD_HEIGHT      = 96      # px tall
HUD_BG_ALPHA    = 228     # HUD background opacity
HUD_BORDER      = C_PRIMARY_LIGHT   # bottom border colour

# ── Fonts  (name, size, bold) ─────────────────────────────────────────────────
# Each is a list of font names tried in order; first one found is used.
FONT_TITLE  = (["Chalkboard SE","Arial Rounded MT Bold"], 40, True)
FONT_MID    = (["Chalkboard SE","Arial Rounded MT Bold"], 26, True)
FONT_BODY   = (["Chalkboard SE","Trebuchet MS"],          17, False)
FONT_BTN    = (["Chalkboard SE","Arial Rounded MT Bold"], 20, True)
FONT_LABEL  = (["Chalkboard SE","Trebuchet MS"],          14, False)
FONT_HUD    = (["Chalkboard SE","Trebuchet MS"],          15, True)
FONT_TIMER  = (["Chalkboard SE","Arial Rounded MT Bold"], 28, True)
FONT_TIMERS = (["Chalkboard SE","Trebuchet MS"],          13, False)

# ── Panels ────────────────────────────────────────────────────────────────────
PANEL_RADIUS      = 28    # rounded corner radius for dialogue panels
PANEL_SHADOW_ALPHA= 35    # panel drop-shadow opacity

# ── Buttons ───────────────────────────────────────────────────────────────────
BTN_RADIUS        = 30    # rounded corner radius for big buttons
BTN_SMALL_RADIUS  = 20    # rounded corner radius for nav buttons

# ── Progress bar ──────────────────────────────────────────────────────────────
BAR_HEIGHT        = 12    # px
BAR_RADIUS        = 6

# ── Timer display ─────────────────────────────────────────────────────────────
TIMER_RADIUS      = 16    # pill radius for the live timer widget

# ── End-screen bar chart ──────────────────────────────────────────────────────
CHART_BAR_H       = 34    # height of each comparison bar
CHART_BAR_GAP     = 12    # vertical gap between bars

# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                     END OF STYLE CONFIGURATION                              ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

TOTAL_PATHOGEN_PAIRS = 10
TOTAL_HEALTHY_PAIRS  = 18
WELCOME, PHASE1, INTERMEZZO, PHASE2, END = 0, 1, 2, 3, 4

# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                       IMAGE ASSETS CONFIGURATION                            ║
# ║  All image files used by the game are listed here.  Replace any filename    ║
# ║  with your own PNG/JPG to reskin that element.  Set a value to None to use  ║
# ║  the built-in fallback art.                                                 ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

# ── Background / decoration ───────────────────────────────────────────────────
# header.png  – decorative banner shown on the Welcome screen (860 × 172 px)
ASSET_HEADER     = "header.png"

# ── Card backs (face-down side) ───────────────────────────────────────────────
# mhc_empty.png – back face used for ALL cards in Phase 1, and healthy cells
#                 in Phase 2.  Design tip: keep this neutral/mysterious.
ASSET_CARD_BACK  = "mhc_empty.png"

# ── Card fronts – healthy cells ───────────────────────────────────────────────
# healthy.png – face-up image for healthy (non-pathogen) cells.
ASSET_HEALTHY    = "healthy.png"

# ── Card fronts – pathogens (5 different germs, IDs 0-4) ─────────────────────
# front_0.png … front_4.png  – what the germ looks like face-up in BOTH phases.
ASSET_FRONTS     = [f"front_{i}.png" for i in range(5)]

# ── Phase-2 pathogen backs (MHC-presented antigen, shown face-DOWN) ──────────
# back_0.png … back_4.png  – MHC-marker hint shown on the card's back in
#                             Phase 2 so players can spot germs more easily.
ASSET_BACKS_P2   = [f"back_{i}.png"  for i in range(5)]

# ── Intermezzo diagram ────────────────────────────────────────────────────────
# MHC.png – educational diagram shown between Phase 1 and Phase 2 (380 × 180 px)
ASSET_MHC_DIAG   = "MHC.png"

# ── Sound effects ─────────────────────────────────────────────────────────────
# Use .ogg for web/pygbag compatibility.  Set to None to silence that event.
SOUND_FLIP      = "flip.ogg"     # card flip
SOUND_POP       = "plop.ogg"     # healthy pair cleared
SOUND_MATCH     = "match.ogg"    # germ pair matched
SOUND_MISMATCH  = "mismatch.ogg" # cards don't match

# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                    END OF IMAGE ASSETS CONFIGURATION                        ║
# ╚══════════════════════════════════════════════════════════════════════════════╝


# ── Math helpers ──────────────────────────────────────────────────────────────
def lerp(a, b, t):    return a + (b - a) * t
def lerp3(c1, c2, t): return tuple(int(lerp(c1[i], c2[i], max(0, min(1, t)))) for i in range(3))
def ease_out(t):      return 1 - (1 - max(0, min(1, t))) ** 3

def fmt_time(ms):
    if ms <= 0: return "0.0s"
    s = ms / 1000.0
    m = int(s) // 60
    return f"{m}:{s - m*60:04.1f}" if m > 0 else f"{s:.1f}s"


# ── Image loading ─────────────────────────────────────────────────────────────
def load_img(path, size):
    """Load an image and smoothscale it. Returns None on failure."""
    try:
        img = pygame.image.load(path).convert_alpha()
        return pygame.transform.smoothscale(img, size)
    except Exception:
        return None

def img_ok(surf):
    """True if surf is a real loaded image (not None and not blank)."""
    if surf is None: return False
    try:
        return surf.get_at((surf.get_width()//2, surf.get_height()//2)).a > 10
    except Exception:
        return False


# ── Drawing primitives ────────────────────────────────────────────────────────
def draw_rect(surf, color, rect, radius=0, border=0, border_color=None):
    if color:
        pygame.draw.rect(surf, color, rect, border_radius=radius)
    if border and border_color:
        pygame.draw.rect(surf, border_color, rect, border, border_radius=radius)

def draw_shadow(surf, rect, radius=20, offset=6, alpha=35):
    sh = pygame.Surface((rect.width+offset*2, rect.height+offset*2), pygame.SRCALPHA)
    pygame.draw.rect(sh, (80, 60, 70, alpha),
                     (offset, offset, rect.width, rect.height), border_radius=radius+4)
    surf.blit(sh, (rect.x-offset, rect.y-offset))

def draw_panel(surf, rect, bg=None, border=None, radius=None, shadow=True):
    bg     = bg     or C_PANEL_BG
    border = border or C_PANEL_BORDER
    radius = radius or PANEL_RADIUS
    if shadow: draw_shadow(surf, rect, radius=radius, alpha=PANEL_SHADOW_ALPHA)
    draw_rect(surf, bg, rect, radius=radius)
    # Top-left shine
    shine = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
    pygame.draw.ellipse(shine, (255,255,255,45), (8, 5, rect.width//2, rect.height//3))
    surf.blit(shine, rect.topleft)
    draw_rect(surf, None, rect, radius=radius, border=3, border_color=border)

def draw_wavy_bg(surf, t):
    bs = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
    for xp, yp, xa, ya, bx, by, r, col in BG_BLOBS:
        pygame.draw.circle(bs, col,
                           (int(bx + math.sin(t*xp+xp)*xa),
                            int(by + math.cos(t*yp+yp)*ya)), r)
    surf.blit(bs, (0, 0))

def draw_sparkles(surf, t):
    for i, (sx, sy) in enumerate(SPARKLE_POSITIONS):
        phase = math.sin(t*2.5 + i*1.1)*0.5 + 0.5
        size  = SPARKLE_MIN_SIZE + phase * (SPARKLE_MAX_SIZE - SPARKLE_MIN_SIZE)
        alpha = int(80 + phase * 160)
        sp    = pygame.Surface((32, 32), pygame.SRCALPHA)
        col   = (*SPARKLE_COLOR, alpha)
        for angle in (0, 90, 180, 270):
            rad = math.radians(angle)
            pygame.draw.line(sp, col, (16,16),
                             (int(16+math.cos(rad)*size), int(16+math.sin(rad)*size)), 2)
        for angle in (45, 135, 225, 315):
            rad = math.radians(angle)
            pygame.draw.line(sp, col, (16,16),
                             (int(16+math.cos(rad)*size*.5), int(16+math.sin(rad)*size*.5)), 1)
        surf.blit(sp, (sx-16, sy-16))


# ── Fallback card art (used when PNG files are missing) ───────────────────────
def draw_germ_face(surf, rect, color, shape="blob"):
    cx, cy = rect.centerx, rect.centery
    r = int(min(rect.width, rect.height) * 0.35)
    if shape == "spiky":
        for a in range(0, 360, 40):
            rad = math.radians(a)
            pygame.draw.circle(surf, lerp3(color, C_WHITE, 0.25),
                               (int(cx+math.cos(rad)*(r+8)), int(cy+math.sin(rad)*(r+8))), 5)
        pygame.draw.circle(surf, color, (cx, cy), r)
    elif shape == "cloud":
        for dx, dy, dr in [(-r//2,2,r//2+2),(r//2,2,r//2+2),(0,-r//4,r//2),(0,4,r)]:
            pygame.draw.circle(surf, color, (cx+dx, cy+dy), dr)
    elif shape == "fuzzy":
        for a in range(0, 360, 25):
            rad  = math.radians(a)
            bump = r + 5 + 3*math.sin(a*0.7)
            pygame.draw.circle(surf, color,
                               (int(cx+math.cos(rad)*bump), int(cy+math.sin(rad)*bump)), 7)
        pygame.draw.circle(surf, color, (cx, cy), r)
    else:
        pygame.draw.circle(surf, color, (cx, cy), r)
    hi = pygame.Surface((r*2, r*2), pygame.SRCALPHA)
    pygame.draw.circle(hi, (255,255,255,110), (r//2+2, r//2), max(4, r//4))
    surf.blit(hi, (cx-r, cy-r))
    ey = cy - r//5
    for ex in (cx-r//3, cx+r//3):
        pygame.draw.circle(surf, (55,42,48), (ex, ey), max(3, r//6))
        pygame.draw.circle(surf, C_WHITE, (ex+1, ey-1), max(1, r//10))
    pygame.draw.arc(surf, (55,42,48),
                    pygame.Rect(cx-r//3, cy+r//10, r*2//3, r//3), math.pi, math.pi*2, 2)
    for ex in (cx-r//2, cx+r//2):
        ch = pygame.Surface((r//2, r//4), pygame.SRCALPHA)
        pygame.draw.ellipse(ch, (255,155,155,90), (0,0,r//2,r//4))
        surf.blit(ch, (ex-r//4, cy+r//10))

def make_fallback_germ(size, p_id):
    surf  = pygame.Surface(size, pygame.SRCALPHA)
    r     = pygame.Rect(0, 0, *size)
    color = FALLBACK_GERM_COLOURS[p_id % len(FALLBACK_GERM_COLOURS)]
    shape = FALLBACK_GERM_SHAPES[p_id % len(FALLBACK_GERM_SHAPES)]
    draw_rect(surf, lerp3(color, C_WHITE, 0.5), r, radius=CARD_RADIUS)
    shine = pygame.Surface(size, pygame.SRCALPHA)
    pygame.draw.ellipse(shine, (255,255,255,60), (5,4,size[0]//2,size[1]//3))
    surf.blit(shine, (0,0))
    draw_germ_face(surf, r, color, shape)
    draw_rect(surf, None, r, radius=CARD_RADIUS, border=3,
              border_color=lerp3(color, C_TEXT, 0.3))
    return surf

def make_fallback_mhc_back(size):
    """Peach dotted card back — used when mhc_empty.png is missing."""
    surf = pygame.Surface(size, pygame.SRCALPHA)
    r    = pygame.Rect(0, 0, *size)
    draw_rect(surf, (255, 210, 170), r, radius=CARD_RADIUS)
    shine = pygame.Surface(size, pygame.SRCALPHA)
    pygame.draw.ellipse(shine, (255,255,255,55), (5,4,size[0]//2,size[1]//3))
    surf.blit(shine, (0,0))
    for row in range(5, size[1]-5, 13):
        for col in range(5, size[0]-5, 13):
            pygame.draw.circle(surf, (230,192,150,70), (col, row), 2)
    cx, cy = size[0]//2, size[1]//2
    pygame.draw.circle(surf, (255,210,190,200), (cx, cy), 16)
    draw_rect(surf, None, r, radius=CARD_RADIUS, border=3, border_color=C_PRIMARY_LIGHT)
    return surf

def make_fallback_healthy(size):
    """Mint smiley card — used when healthy.png is missing."""
    surf = pygame.Surface(size, pygame.SRCALPHA)
    r    = pygame.Rect(0, 0, *size)
    draw_rect(surf, C_SECONDARY_LT, r, radius=CARD_RADIUS)
    shine = pygame.Surface(size, pygame.SRCALPHA)
    pygame.draw.ellipse(shine, (255,255,255,65), (5,4,size[0]//2,size[1]//3))
    surf.blit(shine, (0,0))
    cx, cy = size[0]//2, size[1]//2
    pygame.draw.circle(surf, C_WHITE, (cx, cy), 22)
    for ex in (cx-7, cx+7):
        pygame.draw.circle(surf, (55,42,48), (ex, cy-5), 4)
        pygame.draw.circle(surf, C_WHITE, (ex+1, cy-6), 1)
    pygame.draw.arc(surf, (55,42,48), pygame.Rect(cx-10,cy+2,20,12), math.pi, math.pi*2, 2)
    for ex in (cx-12, cx+12):
        ch = pygame.Surface((12,8), pygame.SRCALPHA)
        pygame.draw.ellipse(ch, (255,160,160,100), (0,0,12,8))
        surf.blit(ch, (ex-6, cy+4))
    draw_rect(surf, None, r, radius=CARD_RADIUS, border=3, border_color=C_SECONDARY)
    return surf


# ── UI widgets ────────────────────────────────────────────────────────────────
def draw_big_button(surf, rect, label, font, mx, my,
                    bg=None, shadow_col=None, text_col=None):
    bg         = bg         or C_PRIMARY
    shadow_col = shadow_col or C_PRIMARY_DARK
    text_col   = text_col   or C_WHITE
    hover = rect.collidepoint(mx, my)    r = rect.inflate(8, 6) if hover else rect
    draw_rect(surf, shadow_col,
              pygame.Rect(r.x+2, r.y+(2 if hover else 5), r.width, r.height),
              radius=BTN_RADIUS)
    draw_rect(surf, bg, r, radius=BTN_RADIUS)
    sn = pygame.Surface((r.width, r.height), pygame.SRCALPHA)
    pygame.draw.ellipse(sn, (255,255,255,65), (10,5,r.width//2,r.height//3))
    surf.blit(sn, r.topleft)
    txt = font.render(label, True, text_col)
    surf.blit(txt, txt.get_rect(center=r.center))
    return hover

def draw_small_button(surf, rect, label, font, mx, my):
    hover = rect.collidepoint(mx, my)
    r = rect.inflate(4, 2) if hover else rect
    draw_rect(surf, C_SHADOW,
              pygame.Rect(r.x+1, r.y+(2 if hover else 4), r.width, r.height),
              radius=BTN_SMALL_RADIUS)
    draw_rect(surf, C_WHITE if hover else C_BG_DARK, r, radius=BTN_SMALL_RADIUS)
    draw_rect(surf, None, r, radius=BTN_SMALL_RADIUS, border=2,
              border_color=C_PRIMARY_LIGHT if hover else C_SHADOW)
    txt = font.render(label, True, C_PRIMARY_DARK if hover else C_TEXT)
    surf.blit(txt, txt.get_rect(center=r.center))
    return hover

def draw_live_timer(surf, elapsed, font_big, font_small, cx, cy, label, color):
    ts   = fmt_time(elapsed)
    tb   = font_big.render(ts,    True, color)
    tl   = font_small.render(label, True, C_TEXT_MED)
    pad  = 18
    w    = max(tb.get_width(), tl.get_width()) + pad*2
    h    = tb.get_height() + tl.get_height() + 20
    pill = pygame.Rect(cx-w//2, cy-h//2, w, h)
    draw_shadow(surf, pill, radius=TIMER_RADIUS, offset=4, alpha=28)
    draw_rect(surf, C_WHITE, pill, radius=TIMER_RADIUS)
    draw_rect(surf, None, pill, radius=TIMER_RADIUS, border=2, border_color=color)
    surf.blit(tl, tl.get_rect(centerx=cx, top=pill.y+8))
    surf.blit(tb, tb.get_rect(centerx=cx, top=pill.y+8+tl.get_height()+4))

def draw_stat_pill(surf, label, value, color, font_lbl, font_val, cx, cy, w=180):
    tl = font_lbl.render(label, True, C_TEXT_MED)
    tv = font_val.render(value, True, color)
    h  = tl.get_height() + tv.get_height() + 16
    r  = pygame.Rect(cx-w//2, cy-h//2, w, h)
    draw_shadow(surf, r, radius=14, offset=4, alpha=28)
    draw_rect(surf, C_WHITE, r, radius=14)
    draw_rect(surf, None, r, radius=14, border=2, border_color=color)
    surf.blit(tl, tl.get_rect(centerx=cx, top=r.y+6))
    surf.blit(tv, tv.get_rect(centerx=cx, top=r.y+6+tl.get_height()+2))

def draw_time_bars(surf, t1_ms, t2_ms, font_body, font_small, cx, top_y, anim_t):
    max_t  = max(t1_ms, t2_ms, 1)
    pw     = 680
    ph     = (CHART_BAR_H + CHART_BAR_GAP + 18)*2 + 60
    panel  = pygame.Rect(cx-pw//2, top_y, pw, ph)
    draw_panel(surf, panel, border=C_ACCENT_LILAC, radius=20)
    hdr = font_body.render("  Round times  ", True, C_TEXT)
    surf.blit(hdr, hdr.get_rect(centerx=cx, top=top_y+10))
    rows = [
        ("Phase 1  (germs hidden)",       t1_ms, C_PRIMARY,   0.00),
        ("Phase 2  (MHC markers visible)", t2_ms, C_SECONDARY, 0.25),
    ]
    for i, (lbl, ms, col, delay) in enumerate(rows):
        by = top_y + 46 + i*(CHART_BAR_H+CHART_BAR_GAP+18)
        surf.blit(font_small.render(lbl, True, C_TEXT_MED), (panel.x+16, by))
        track = pygame.Rect(panel.x+16, by+18, pw-32, CHART_BAR_H)
        draw_rect(surf, C_BG_DARK, track, radius=CHART_BAR_H//2)
        prog  = ease_out(min(max(anim_t-delay, 0)*0.9, 1.0))
        fw    = max(CHART_BAR_H, int((ms/max_t)*(pw-32)*prog))
        fill  = pygame.Rect(track.x, track.y, fw, CHART_BAR_H)
        draw_rect(surf, col, fill, radius=CHART_BAR_H//2)
        sn = pygame.Surface((fw, CHART_BAR_H), pygame.SRCALPHA)
        pygame.draw.rect(sn, (255,255,255,70), (0,0,fw,CHART_BAR_H//2), border_radius=CHART_BAR_H//2)
        surf.blit(sn, fill.topleft)
        ts = font_small.render(fmt_time(ms), True, C_WHITE)
        surf.blit(ts, (fill.right-ts.get_width()-10, fill.centery-ts.get_height()//2))
    if t2_ms > 0 and t1_ms > 0:
        if t2_ms < t1_ms:
            pct = int((1-t2_ms/max(t1_ms,1))*100)
            btxt, bcol = f"  {pct}% faster with MHC!  ", C_SECONDARY
        else:
            btxt, bcol = "  Keep practising — MHC usually speeds things up!  ", C_AMBER_DARK
        bt = font_body.render(btxt, True, C_WHITE)
        bw, bh = bt.get_width()+16, bt.get_height()+10
        br = pygame.Rect(cx-bw//2, panel.bottom-bh-10, bw, bh)
        draw_rect(surf, bcol, br, radius=bh//2)
        surf.blit(bt, bt.get_rect(center=br.center))


# ── Card class ────────────────────────────────────────────────────────────────
class Card:
    def __init__(self, p_id, front, back, x, y, born_t=0):
        self.pathogen_id  = p_id   # -1 = healthy, 0-4 = pathogen
        self.front_image  = front
        self.back_image   = back
        self.base_rect    = pygame.Rect(x, y, CARD_SIZE, CARD_SIZE)
        self.rect         = self.base_rect.copy()
        self.is_flipped   = False
        self.status       = "ACTIVE"
        self.ever_flipped = False
        self.scale        = 1.0
        self.bob_phase    = random.uniform(0, math.pi*2)
        self.flash_alpha  = 0
        self.flash_color  = C_GOOD
        self.born_t       = born_t

    def update(self, mx, my, t):
        hovering   = self.base_rect.collidepoint(mx, my)
        self.scale = lerp(self.scale, CARD_HOVER_SCALE if hovering else 1.0, 0.14)
        # No bob — card stays in place; only the scale grow shows on hover
        n = int(CARD_SIZE * self.scale)
        self.rect = pygame.Rect(0, 0, n, n)
        self.rect.center = (self.base_rect.centerx, self.base_rect.centery)
        if self.flash_alpha > 0:
            self.flash_alpha = max(0, self.flash_alpha-7)

    def draw(self, surf, t):
        if self.status != "ACTIVE": return
        # Drop shadow
        sh = pygame.Surface((self.rect.width+8, self.rect.height+8), pygame.SRCALPHA)
        pygame.draw.rect(sh, (80,60,70,CARD_SHADOW_ALPHA),
                         (4, 6, self.rect.width, self.rect.height), border_radius=CARD_RADIUS+2)
        surf.blit(sh, (self.rect.x-4, self.rect.y-2))
        # Card image
        img = pygame.transform.smoothscale(
            self.front_image if self.is_flipped else self.back_image,
            (self.rect.width, self.rect.height))
        surf.blit(img, self.rect)
        # Hover ring
        if self.scale > 1.02:
            pygame.draw.rect(surf, C_PRIMARY_LIGHT, self.rect, 3, border_radius=CARD_RADIUS)
        # Flipped pulse ring
        if self.is_flipped:
            pulse  = 0.5+0.5*math.sin(t*4)
            ring_c = lerp3(C_PRIMARY_LIGHT, C_PRIMARY_DARK, pulse)
            pygame.draw.rect(surf, ring_c, self.rect, 3, border_radius=CARD_RADIUS)
        # Flash overlay
        if self.flash_alpha > 0:
            fl = pygame.Surface((self.rect.width, self.rect.height), pygame.SRCALPHA)
            pygame.draw.rect(fl, (*self.flash_color, self.flash_alpha),
                             (0,0,self.rect.width,self.rect.height), border_radius=CARD_RADIUS)
            surf.blit(fl, self.rect.topleft)


# ── Main ─────────────────────────────────────────────────────────────────────
async def main():
    # Display must be initialised first — pygbag needs this before any await.
    pygame.init()
    screen = pygame.display.set_mode((SCREEN_W, SCREEN_H))
    pygame.display.set_caption("Germ Hide & Seek")
    clock  = pygame.time.Clock()

    # Flush a plain background frame immediately so the browser canvas is never
    # grey during asset loading.  pygbag requires at least one flip+await early.
    screen.fill(C_BG)
    pygame.display.flip()
    await asyncio.sleep(0)

    # Mixer is optional — WASM audio can silently fail; never let it block startup.
    try:
        pygame.mixer.pre_init(44100, -16, 2, 512)
        pygame.mixer.init()
    except Exception:
        pass

    def make_font(spec):
        names, size, bold = spec
        for name in names:
            try:
                f = pygame.font.SysFont(name, size, bold=bold)
                if f: return f
            except: pass
        return pygame.font.SysFont("Arial", size, bold=bold)

    font_title  = make_font(FONT_TITLE)
    font_mid    = make_font(FONT_MID)
    font_body   = make_font(FONT_BODY)
    font_btn    = make_font(FONT_BTN)
    font_label  = make_font(FONT_LABEL)
    font_hud    = make_font(FONT_HUD)
    font_timer  = make_font(FONT_TIMER)
    font_timers = make_font(FONT_TIMERS)

    # ── Load card images at CARD_SIZE × CARD_SIZE ─────────────────────────────
    SZ = (CARD_SIZE, CARD_SIZE)

    # mhc_empty.png — back face for ALL cards in BOTH phases
    mhc_back = load_img(ASSET_CARD_BACK, SZ)
    if not img_ok(mhc_back):
        mhc_back = make_fallback_mhc_back(SZ)

    # healthy.png — front face for healthy cells (both phases)
    healthy_front = load_img(ASSET_HEALTHY, SZ)
    if not img_ok(healthy_front):
        healthy_front = make_fallback_healthy(SZ)

    # front_0 … front_4 — pathogen front faces (both phases)
    front_imgs = []
    for i in range(5):
        img = load_img(ASSET_FRONTS[i], SZ)
        if not img_ok(img): img = make_fallback_germ(SZ, i)
        front_imgs.append(img)

    # back_0 … back_4 — Phase 2 pathogen backs (MHC-presented antigens)
    back_imgs = []
    for i in range(5):
        img = load_img(ASSET_BACKS_P2[i], SZ)
        if not img_ok(img): img = make_fallback_germ(SZ, i)
        back_imgs.append(img)

    # Other assets (not square)
    header_img = load_img(ASSET_HEADER,   (860, 172))
    mhc_diag   = load_img(ASSET_MHC_DIAG, (380, 180))

    # ── Sound effects ─────────────────────────────────────────────────────────
    # Each sound is loaded individually — a missing file only silences that one.
    # Supported formats: .ogg (best for web/pygbag), .wav (desktop fallback).
    # To add your own sounds, replace the filenames in SOUND_* at the top.
    def _load_snd(path):
        if path is None: return None
        try:
            s = pygame.mixer.Sound(path)
            s.set_volume(0.7)
            return s
        except Exception:
            return None

    snd_flip  = _load_snd(SOUND_FLIP)
    snd_pop   = _load_snd(SOUND_POP)
    snd_match = _load_snd(SOUND_MATCH)
    snd_miss  = _load_snd(SOUND_MISMATCH)

    # ── State ─────────────────────────────────────────────────────────────────
    state                = WELCOME
    cards                = []
    selected             = []
    pathogen_pairs_found = 0
    healthy_pairs_found  = 0
    flip_back_t          = 0
    pop_msg              = ""
    pop_msg_t            = 0
    pop_scale            = 0.0

    phase_start_ms   = 0
    phase1_time_ms   = 0
    phase2_time_ms   = 0
    p1_healthy_pairs = 0
    p2_healthy_pairs = 0
    compare_anim     = 0.0

    def reset_timer():
        nonlocal phase_start_ms
        phase_start_ms = pygame.time.get_ticks()

    def elapsed():
        return pygame.time.get_ticks() - phase_start_ms

    def reset_counters():
        nonlocal pathogen_pairs_found, healthy_pairs_found
        pathogen_pairs_found = 0
        healthy_pairs_found  = 0

    def setup_board(is_phase2):
        """
        Build a freshly shuffled board.
        56 cards: 5 pathogens × 4 copies + 36 healthy cells.

        Card image assignment:
          front  (face-up)  : front_0…4 for pathogens; healthy.png for healthy
          back   (face-down):
            Phase 1 — mhc_empty.png for ALL cards (pathogens + healthy)
            Phase 2 — back_0…4 for pathogens; mhc_empty.png for healthy
        """
        p_ids   = list(range(5)) * 4 + [-1] * 36
        random.shuffle(p_ids)                     # fresh random seed every call
        grid_w  = CARD_COLS * (CARD_SIZE + CARD_MARGIN) - CARD_MARGIN
        start_x = (SCREEN_W - grid_w) // 2
        now_ms  = pygame.time.get_ticks()
        result  = []
        for idx, p_id in enumerate(p_ids):
            col, row = idx % CARD_COLS, idx // CARD_COLS
            x = start_x + col * (CARD_SIZE + CARD_MARGIN)
            y = 302     + row * (CARD_SIZE + CARD_MARGIN)

            if p_id == -1:
                # Healthy cell:
                #   front  = healthy.png   (both phases)
                #   back   = mhc_empty.png (both phases)
                front = healthy_front
                back  = mhc_back
            else:
                # Pathogen:
                #   front  = front_{p_id}.png  (both phases)
                #   back   = mhc_empty.png     (Phase 1)
                #          = back_{p_id}.png   (Phase 2)
                front = front_imgs[p_id]
                back  = back_imgs[p_id] if is_phase2 else mhc_back

            result.append(Card(p_id, front, back, x, y, born_t=now_ms + idx*16))
        return result

    # ── Game loop ─────────────────────────────────────────────────────────────
    while True:
        clock.tick(60)
        now    = pygame.time.get_ticks()
        t      = now / 1000.0
        # Scale raw mouse/event coordinates into logical game space.
        # pygbag resizes the canvas to fit the browser window, so raw pixel
        # positions must be mapped back to the fixed SCREEN_W × SCREEN_H grid.
        def _scale_pos(raw_x, raw_y):
            win_w, win_h = pygame.display.get_surface().get_size()
            sx = raw_x * SCREEN_W / win_w if win_w else raw_x
            sy = raw_y * SCREEN_H / win_h if win_h else raw_y
            return int(sx), int(sy)

        raw_mx, raw_my = pygame.mouse.get_pos()
        mx, my = _scale_pos(raw_mx, raw_my)
        click  = False
        click_pos = (mx, my)
        for event in pygame.event.get():
            if event.type == pygame.QUIT: return
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                click = True
                click_pos = _scale_pos(*event.pos)
        cmx, cmy = click_pos

        screen.fill(C_BG)
        draw_wavy_bg(screen, t)

        # ─────────────────────────── WELCOME ─────────────────────────────────
        if state == WELCOME:
            if img_ok(header_img):
                screen.blit(header_img, (SCREEN_W//2-430, 28))

            mp = pygame.Rect(SCREEN_W//2-360, 218, 720, 202)
            draw_panel(screen, mp, border=C_PRIMARY_LIGHT, radius=PANEL_RADIUS)
            ts = font_mid.render("Your mission, should you choose to accept it...", True, C_PRIMARY_DARK)
            screen.blit(ts, ts.get_rect(center=(SCREEN_W//2, mp.y+36)))
            for i, line in enumerate([
                "Find the germs hiding inside cells!",
                "Match two identical germs to clear them out.",
                "Healthy cells have no match — avoid them if you can!",
            ]):
                screen.blit(font_body.render(line, True, C_TEXT), (mp.x+50, mp.y+74+i*38))

            for idx, (lbl, bg, bc) in enumerate([
                ("Phase 1  •  Germs are hiding!",      C_PRIMARY_LIGHT, C_PRIMARY_DARK),
                ("Phase 2  •  They're on the surface!", C_SECONDARY_LT,  C_SECONDARY),
            ]):
                pill = pygame.Rect(SCREEN_W//2-340+idx*360, 438, 320, 44)
                draw_panel(screen, pill, bg=bg, border=bc, radius=22)
                ls = font_label.render(lbl, True, C_WHITE)
                screen.blit(ls, ls.get_rect(center=pill.center))

            btn_r = pygame.Rect(SCREEN_W//2-130, 505, 260, 56)
            if draw_big_button(screen, btn_r, "  Start Game!", font_btn, mx, my):
                if click:
                    reset_counters()
                    cards = setup_board(False)
                    reset_timer()
                    state = PHASE1
            draw_sparkles(screen, t)

        # ─────────────────────────── GAME PHASES ─────────────────────────────
        elif state in (PHASE1, PHASE2):
            # HUD
            hud_s = pygame.Surface((SCREEN_W, HUD_HEIGHT), pygame.SRCALPHA)
            pygame.draw.rect(hud_s, (*C_WHITE, HUD_BG_ALPHA), (0, 0, SCREEN_W, HUD_HEIGHT))
            screen.blit(hud_s, (0, 0))
            pygame.draw.line(screen, HUD_BORDER, (0, HUD_HEIGHT), (SCREEN_W, HUD_HEIGHT), 2)

            # Nav buttons
            menu_hover = draw_small_button(screen, pygame.Rect(14,12,90,32), "  Menu", font_label, mx, my)
            back_hover = False
            if state == PHASE2:
                back_hover = draw_small_button(screen, pygame.Rect(112,12,90,32), "  Back", font_label, mx, my)
            if click:
                if menu_hover:
                    state = WELCOME; reset_counters(); selected, flip_back_t = [], 0
                elif back_hover:
                    state = INTERMEZZO; reset_counters(); selected, flip_back_t = [], 0

            # Phase label
            ph_str = ("Phase 1  •  Where are the germs?"
                      if state == PHASE1 else
                      "Phase 2  •  They're showing themselves!")
            ph_surf = font_hud.render(ph_str, True, C_PRIMARY_DARK)
            screen.blit(ph_surf, ph_surf.get_rect(center=(SCREEN_W//2, 14)))

            # Live timer (top-right)
            draw_live_timer(screen, elapsed(), font_timer, font_timers,
                            cx=SCREEN_W-96, cy=HUD_HEIGHT//2,
                            label="Phase 1" if state == PHASE1 else "Phase 2",
                            color=C_PRIMARY_DARK if state == PHASE1 else C_SECONDARY)

            # Germ counter (pink dots)
            g_lbl = font_label.render("Germs caught:", True, C_PRIMARY_DARK)
            screen.blit(g_lbl, (220, 32))
            gx0 = 220 + g_lbl.get_width() + 8
            for si in range(TOTAL_PATHOGEN_PAIRS):
                sc = pygame.Surface((16,16), pygame.SRCALPHA)
                filled = si < pathogen_pairs_found
                pygame.draw.circle(sc, C_AMBER if filled else C_SHADOW, (8,8), 7)
                if filled: pygame.draw.circle(sc, (255,240,180), (5,5), 3)
                screen.blit(sc, (gx0+si*19, 32))

            # Healthy counter (mint dots)
            h_lbl = font_label.render("Healthy pairs opened:", True, C_SECONDARY)
            screen.blit(h_lbl, (220, 52))
            hx0 = 220 + h_lbl.get_width() + 8
            for si in range(min(healthy_pairs_found+1, TOTAL_HEALTHY_PAIRS)):
                sc = pygame.Surface((16,16), pygame.SRCALPHA)
                filled = si < healthy_pairs_found
                pygame.draw.circle(sc, C_SECONDARY if filled else C_SHADOW, (8,8), 7)
                if filled: pygame.draw.circle(sc, (180,240,200), (5,5), 3)
                screen.blit(sc, (hx0+si*19, 52))
            if healthy_pairs_found > 0:
                w_surf = font_label.render(
                    f"  {healthy_pairs_found} opened — try to avoid healthy cells!", True, C_BAD)
                screen.blit(w_surf, (hx0 + min(healthy_pairs_found,18)*19+4, 52))

            # Progress bar
            bar = pygame.Rect(26, 78, SCREEN_W-220, BAR_HEIGHT)
            draw_rect(screen, C_BG_DARK, bar, radius=BAR_RADIUS)
            if pathogen_pairs_found:
                fw = max(BAR_HEIGHT, int((bar.width-4)*pathogen_pairs_found/TOTAL_PATHOGEN_PAIRS))
                fr = pygame.Rect(bar.x+2, bar.y+2, fw, bar.height-4)
                pulse = 0.5+0.5*math.sin(t*3)
                draw_rect(screen, lerp3(C_PRIMARY, C_PRIMARY_LIGHT, pulse), fr, radius=BAR_RADIUS-1)
                sn = pygame.Surface((fr.width,fr.height), pygame.SRCALPHA)
                pygame.draw.rect(sn,(255,255,255,80),(0,0,fr.width,fr.height//2),border_radius=BAR_RADIUS)
                screen.blit(sn, fr.topleft)

            # Hint
            gl = font_label.render("Tap a cell to peek inside!", True, C_TEXT_MED)
            screen.blit(gl, gl.get_rect(center=(SCREEN_W//2, HUD_HEIGHT+10)))

            # Cards
            for c in cards:
                if c.status != "ACTIVE": continue
                age = now - c.born_t
                if age < 280:
                    prog_in = ease_out(max(0,age)/250)
                    tmp = pygame.Surface((CARD_SIZE, CARD_SIZE), pygame.SRCALPHA)
                    tmp.blit(c.back_image, (0,0))
                    tmp.set_alpha(int(prog_in*255))
                    screen.blit(tmp, (c.base_rect.x, c.base_rect.y+int((1-prog_in)*50)))
                    continue
                c.update(mx, my, t)
                c.draw(screen, t)
                if (click and c.base_rect.collidepoint(cmx, cmy)
                        and len(selected) < 2
                        and not c.is_flipped
                        and flip_back_t == 0):
                    c.is_flipped   = True
                    c.ever_flipped = True
                    if snd_flip: snd_flip.play()
                    selected.append(c)
                    if len(selected) == 2:
                        flip_back_t = now + 950

            # Match logic
            if flip_back_t and now > flip_back_t:
                a, b = selected
                if a.pathogen_id == b.pathogen_id:
                    a.status = b.status = "CLEARED"
                    a.flash_color = b.flash_color = C_GOOD
                    a.flash_alpha = b.flash_alpha = 220
                    if a.pathogen_id == -1:
                        healthy_pairs_found += 1
                        pop_msg   = "Healthy cell cleared — try to avoid them!"
                        pop_msg_t = now + 1200; pop_scale = 0.0
                        if snd_pop: snd_pop.play()
                    else:
                        pathogen_pairs_found += 1
                        pop_msg   = "Gotcha! Germ caught!"
                        pop_msg_t = now + 1400; pop_scale = 0.0
                        if snd_match: snd_match.play()
                else:
                    a.is_flipped = b.is_flipped = False
                    a.flash_color = b.flash_color = C_BAD
                    a.flash_alpha = b.flash_alpha = 160
                    pop_msg   = "Not a match — try again!"
                    pop_msg_t = now + 900; pop_scale = 0.0
                    if snd_miss: snd_miss.play()
                selected, flip_back_t = [], 0

            # Pop message
            if pop_msg and now < pop_msg_t:
                pop_scale = min(pop_scale+0.12, 1.0)
                sc    = ease_out(pop_scale)
                alpha = min(255, int((pop_msg_t-now)*0.55))
                pm    = font_mid.render(pop_msg, True, C_PRIMARY_DARK)
                pm    = pygame.transform.smoothscale(
                    pm, (int(pm.get_width()*sc), int(pm.get_height()*sc)))
                pm.set_alpha(alpha)
                screen.blit(pm, pm.get_rect(center=(SCREEN_W//2, HUD_HEIGHT+32)))

            # Phase complete
            if pathogen_pairs_found == TOTAL_PATHOGEN_PAIRS:
                if state == PHASE1:
                    phase1_time_ms   = elapsed()
                    p1_healthy_pairs = healthy_pairs_found
                    state = INTERMEZZO
                else:
                    phase2_time_ms   = elapsed()
                    p2_healthy_pairs = healthy_pairs_found
                    compare_anim     = 0.0
                    state = END
                reset_counters()

        # ─────────────────────────── INTERMEZZO ──────────────────────────────
        elif state == INTERMEZZO:
            panel = pygame.Rect(SCREEN_W//2-420, 46, 840, 694)
            draw_panel(screen, panel, border=C_ACCENT_LILAC, radius=PANEL_RADIUS)

            if draw_small_button(screen, pygame.Rect(panel.x+16,panel.y+16,90,30),
                                  "  Menu", font_label, mx, my):
                if click: state = WELCOME; reset_counters()

            h1 = font_title.render("Phase 1 Complete!", True, C_PRIMARY_DARK)
            screen.blit(h1, h1.get_rect(center=(SCREEN_W//2, 104)))

            for ci, (lbl, val, col) in enumerate([
                ("Phase 1 time",         fmt_time(phase1_time_ms), C_AMBER_DARK),
                ("Germ pairs",           "10 / 10",                C_PRIMARY_DARK),
                ("Healthy pairs opened", str(p1_healthy_pairs),    C_SECONDARY),
            ]):
                draw_stat_pill(screen, lbl, val, col, font_label, font_mid,
                               cx=panel.x+148+ci*186, cy=148, w=172)

            h2 = font_mid.render("Science unlocked: MHC molecules!", True, C_ACCENT_LILAC)
            screen.blit(h2, h2.get_rect(center=(SCREEN_W//2, 200)))
            pygame.draw.line(screen, C_ACCENT_LILAC2, (panel.x+60,218),(panel.right-60,218), 2)

            if img_ok(mhc_diag):
                screen.blit(mhc_diag, (SCREEN_W//2-190, 226))

            for i, (line, col, fnt) in enumerate([
                ("What just happened?",                                        C_PRIMARY_DARK, font_hud),
                ("In Phase 1, germs hid deep inside cells — sneaky!",          C_TEXT,         font_body),
                ("MHC molecules now carry germ clues up to the cell surface",  C_TEXT,         font_body),
                ("so the immune system spots infections from the outside.",     C_TEXT,         font_body),
                ("In Phase 2 the germ markers are visible — you should be",    C_SECONDARY,    font_hud),
                ("faster AND open fewer healthy cells. Timer is watching!",    C_SECONDARY,    font_hud),
            ]):
                screen.blit(fnt.render(line, True, col), (panel.x+52, 426+i*36))

            btn = pygame.Rect(SCREEN_W//2-145, 648, 290, 52)
            if draw_big_button(screen, btn, "On to Phase 2!  ->", font_btn, mx, my,
                               bg=C_SECONDARY, shadow_col=lerp3(C_SECONDARY,(40,80,50),0.5)):
                if click:
                    reset_counters()
                    cards = setup_board(True)
                    reset_timer()
                    state = PHASE2
            draw_sparkles(screen, t)

        # ─────────────────────────── END ──────────────────────────────────────
        elif state == END:
            compare_anim += 1/60.0

            panel = pygame.Rect(SCREEN_W//2-430, 34, 860, 716)
            draw_panel(screen, panel, border=C_SECONDARY, radius=PANEL_RADIUS)

            if draw_small_button(screen, pygame.Rect(panel.x+16,panel.y+16,90,30),
                                  "  Menu", font_label, mx, my):
                if click: state = WELCOME; reset_counters()

            bounce = math.sin(t*2.5)*5
            e1 = font_title.render("Mission Complete!", True, C_AMBER)
            screen.blit(e1, e1.get_rect(center=(SCREEN_W//2, int(92+bounce))))
            pygame.draw.line(screen, C_SECONDARY_LT, (panel.x+60,122),(panel.right-60,122), 2)

            draw_time_bars(screen, phase1_time_ms, phase2_time_ms,
                           font_body, font_label, cx=SCREEN_W//2, top_y=132, anim_t=compare_anim)

            # Stats table
            tab_y   = 356
            col_xs  = [SCREEN_W//2-290, SCREEN_W//2-80, SCREEN_W//2+110, SCREEN_W//2+310]

            for ci, (lbl, col) in enumerate([("Stat",C_TEXT_MED),("Phase 1",C_PRIMARY_DARK),
                                              ("Phase 2",C_SECONDARY),("Improvement?",C_AMBER_DARK)]):
                ls = font_hud.render(lbl, True, col)
                screen.blit(ls, ls.get_rect(center=(col_xs[ci], tab_y)))
            pygame.draw.line(screen, C_BG_DARK, (panel.x+30,tab_y+18),(panel.right-30,tab_y+18),1)

            for ci, (val, col) in enumerate([("Time",C_TEXT),
                                              (fmt_time(phase1_time_ms),C_PRIMARY_DARK),
                                              (fmt_time(phase2_time_ms),C_SECONDARY)]):
                screen.blit(font_mid.render(val,True,col),
                            font_mid.render(val,True,col).get_rect(center=(col_xs[ci],tab_y+46)))
            if phase2_time_ms < phase1_time_ms:
                pct = int((1-phase2_time_ms/max(phase1_time_ms,1))*100)
                bt, bc = f"{pct}% faster!", C_SECONDARY
            else:
                bt, bc = "Keep going!", C_AMBER_DARK
            screen.blit(font_hud.render(bt,True,bc),
                        font_hud.render(bt,True,bc).get_rect(center=(col_xs[3],tab_y+46)))

            for ci, (val, col) in enumerate([("Healthy cells opened",C_TEXT),
                                              (str(p1_healthy_pairs),C_PRIMARY_DARK),
                                              (str(p2_healthy_pairs),C_SECONDARY)]):
                screen.blit(font_mid.render(val,True,col),
                            font_mid.render(val,True,col).get_rect(center=(col_xs[ci],tab_y+84)))
            if p2_healthy_pairs < p1_healthy_pairs:
                bt2, bc2 = f"{p1_healthy_pairs-p2_healthy_pairs} fewer!", C_SECONDARY
            elif p2_healthy_pairs == 0 and p1_healthy_pairs == 0:
                bt2, bc2 = "Perfect both rounds!", C_AMBER
            elif p2_healthy_pairs == p1_healthy_pairs:
                bt2, bc2 = "Same", C_TEXT_MED
            else:
                bt2, bc2 = "More — try again!", C_BAD
            screen.blit(font_hud.render(bt2,True,bc2),
                        font_hud.render(bt2,True,bc2).get_rect(center=(col_xs[3],tab_y+84)))

            pygame.draw.line(screen, C_SECONDARY_LT,
                             (panel.x+60,tab_y+112),(panel.right-60,tab_y+112),1)
            for i, (line, col, fnt) in enumerate([
                ("MHC molecules display germ clues right on the cell surface.", C_TEXT,         font_body),
                ("That's why the immune system finds infections so much faster",C_TEXT,         font_body),
                ("— and wastes less effort on healthy cells!",                  C_PRIMARY_DARK, font_hud),
                ("That's exactly what you just experienced. Nice work!",         C_PRIMARY_DARK, font_hud),
            ]):
                screen.blit(fnt.render(line,True,col),
                            fnt.render(line,True,col).get_rect(center=(SCREEN_W//2,tab_y+124+i*32)))

            for i in range(5):
                gc  = pygame.Surface((48,48), pygame.SRCALPHA)
                draw_germ_face(gc, pygame.Rect(0,0,48,48),
                               FALLBACK_GERM_COLOURS[i], FALLBACK_GERM_SHAPES[i])
                bob = math.sin(t*2.5+i*0.8)*4
                screen.blit(gc, (SCREEN_W//2-120+i*50, int(tab_y+258+bob)))

            btn = pygame.Rect(SCREEN_W//2-130, panel.bottom-66, 260, 52)
            if draw_big_button(screen, btn, "Play Again!", font_btn, mx, my):
                if click:
                    phase1_time_ms = phase2_time_ms = 0
                    p1_healthy_pairs = p2_healthy_pairs = 0
                    reset_counters()
                    state = WELCOME
            draw_sparkles(screen, t)

        pygame.display.flip()
        await asyncio.sleep(0)


if __name__ == "__main__":
    asyncio.run(main())
